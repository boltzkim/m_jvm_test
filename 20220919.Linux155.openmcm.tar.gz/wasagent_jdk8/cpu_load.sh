#!/bin/sh
java -cp cpuloadgenerator.jar GenerateCPULoad 
