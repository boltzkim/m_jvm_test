package java.net;

import com.hp.mcm.adapter.api.CodeData;
import com.hp.mcm.adapter.decoration.SocketDecoration;
import com.hp.mcm.adapter.decoration.ThreadDecoration;
import com.hp.mcm.adapter.ref.SocketWeakReference;
import com.sap.jvm.extension.java.base.NativeTracer;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.SocketChannel;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import jdk.internal.misc.JavaNetInetAddressAccess;
import jdk.internal.misc.SharedSecrets;
import sun.net.ApplicationProxy;
import sun.security.util.SecurityConstants;

public class Socket implements Closeable {
  private boolean created = false;
  
  private boolean bound = false;
  
  private boolean connected = false;
  
  private boolean closed = false;
  
  private Object closeLock = new Object();
  
  private boolean shutIn = false;
  
  private boolean shutOut = false;
  
  JavaNetInetAddressAccess jna = SharedSecrets.getJavaNetInetAddressAccess();
  
  static class NetworkDestination {
    private boolean ipv6;
    
    private byte[] fullBytes;
    
    private boolean hasLastByte = false;
    
    private byte lastByte = 0;
    
    private byte lastMask = 0;
    
    NetworkDestination(InetAddress netAddress, short prefix) {
      this.ipv6 = netAddress instanceof Inet6Address;
      byte[] netBytes = netAddress.getAddress();
      int fullByteCount = prefix / 8;
      if (fullByteCount > netBytes.length)
        fullByteCount = netBytes.length; 
      this.fullBytes = new byte[fullByteCount];
      for (int i = 0; i < fullByteCount; i++)
        this.fullBytes[i] = netBytes[i]; 
      if (fullByteCount < netBytes.length) {
        int lastByteBits = prefix % 8;
        if (lastByteBits != 0) {
          this.lastMask = (byte)(255 << 8 - lastByteBits);
          this.lastByte = (byte)(netBytes[fullByteCount] & this.lastMask);
          this.hasLastByte = true;
        } 
      } 
    }
    
    boolean match(InetAddress target) {
      if (this.ipv6 && target instanceof Inet4Address)
        return false; 
      byte[] addressBytes = target.getAddress();
      int i = 0;
      for (; i < this.fullBytes.length && i < addressBytes.length; i++) {
        if (addressBytes[i] != this.fullBytes[i])
          return false; 
      } 
      if (this.hasLastByte && i < addressBytes.length && (addressBytes[i] & this.lastMask) != this.lastByte)
        return false; 
      return true;
    }
    
    static boolean matchList(InetAddress target, List<NetworkDestination> networkList) {
      if (networkList == null)
        return false; 
      for (NetworkDestination network : networkList) {
        if (network.match(target))
          return true; 
      } 
      return false;
    }
  }
  
  private static InetSocketAddress defaultLocalSocketAddress = null;
  
  private static List<NetworkDestination> defaultLocalSocketExceptions = null;
  
  SocketImpl impl;
  
  static {
    configureDefaultLocalSocketAddress();
  }
  
  private static void configureDefaultLocalSocketAddress() {
    String defaultLocalSocketAddressString = AccessController.<String>doPrivileged(() -> System.getProperty("com.sap.jvm.net.DefaultLocalSocketAddress"));
    if (defaultLocalSocketAddressString == null) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr("No default local socket address set.\n");
      return;
    } 
    String[] defaultLocalSocketAddressParts = defaultLocalSocketAddressString.split(";");
    if (defaultLocalSocketAddressParts.length == 0 || defaultLocalSocketAddressParts[0].isEmpty()) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr("Default local socket address property is empty.\n");
      return;
    } 
    NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Resolving default local socket address: \"" + defaultLocalSocketAddressParts[0] + "\".\n");
    InetAddress defaultLocalSocketInetAddress = null;
    try {
      defaultLocalSocketInetAddress = InetAddress.getByName(defaultLocalSocketAddressParts[0]);
    } catch (UnknownHostException e) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> {
            StringBuilder msg = new StringBuilder("\t" + e.getMessage() + "\n");
            for (StackTraceElement el : e.getStackTrace())
              msg.append("\tat " + el.toString() + "\n"); 
            return msg.toString();
          });
    } 
    if (defaultLocalSocketInetAddress == null) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr("Could not resolve default local socket address.\n");
      return;
    } 
    InetAddress inetaddrForTrace = defaultLocalSocketInetAddress;
    NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Resolved default local socket address to \"" + inetaddrForTrace + "\".\n");
    if (defaultLocalSocketInetAddress.isLoopbackAddress()) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr("Resolved default local socket address is a loopback address, ignore it.\n");
      return;
    } 
    Enumeration<NetworkInterface> interfaces = null;
    try {
      interfaces = NetworkInterface.getNetworkInterfaces();
    } catch (SocketException e) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> {
            StringBuilder msg = new StringBuilder("\t" + e.getMessage() + "\n");
            for (StackTraceElement el : e.getStackTrace())
              msg.append("\tat " + el.toString() + "\n"); 
            return msg.toString();
          });
    } 
    if (interfaces == null) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr("Enumerating local network interfaces returned null.\n");
      return;
    } 
    boolean foundLocally = false;
    while (interfaces.hasMoreElements()) {
      NetworkInterface ni = interfaces.nextElement();
      try {
        if (ni.isLoopback())
          continue; 
        if (!ni.isUp())
          continue; 
      } catch (SocketException e) {
        NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> {
              StringBuilder msg = new StringBuilder("Caught exception when determining interface characteristics of interface " + ni.getDisplayName() + ":");
              msg.append("\t" + e.getMessage() + "\n");
              for (StackTraceElement el : e.getStackTrace())
                msg.append("\tat " + el.toString() + "\n"); 
              return msg.toString();
            });
        continue;
      } 
      Enumeration<InetAddress> niaddresses = ni.getInetAddresses();
      while (niaddresses.hasMoreElements()) {
        if (defaultLocalSocketInetAddress.equals(niaddresses.nextElement())) {
          foundLocally = true;
          NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Default local socket address is an address on interface \"" + ni.getDisplayName() + "\".\n");
          break;
        } 
      } 
      if (foundLocally)
        break; 
    } 
    if (!foundLocally) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Default local socket address \"" + inetaddrForTrace + "\" is not a local interface address.\n");
      return;
    } 
    NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Setting default local socket address to \"" + inetaddrForTrace + "\".\n");
    defaultLocalSocketAddress = new InetSocketAddress(defaultLocalSocketInetAddress, 0);
    if (defaultLocalSocketAddressParts.length > 1) {
      defaultLocalSocketExceptions = new ArrayList<>();
      for (int i = 1; i < defaultLocalSocketAddressParts.length; i++) {
        String currPart = defaultLocalSocketAddressParts[i];
        String[] exceptionParts = currPart.split("/");
        if (exceptionParts.length != 2) {
          NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Network Exception \"" + currPart + "\" is invalid.\n");
        } else {
          InetAddress ia = null;
          try {
            ia = InetAddress.getByName(exceptionParts[0]);
          } catch (UnknownHostException e) {
            NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Error adding exception for default local socket address. IP part of \"" + currPart + "\" is invalid.\n");
          } 
          short prefix = 0;
          try {
            prefix = Short.parseShort(exceptionParts[1]);
          } catch (NumberFormatException e) {
            NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Error adding exception for default local socket address. Prefix part of \"" + currPart + "\" is invalid.\n");
          } 
          NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Adding exception \"" + currPart + "\" for default local socket address usage.\n");
          defaultLocalSocketExceptions.add(new NetworkDestination(ia, prefix));
        } 
      } 
      if (defaultLocalSocketExceptions.size() == 0)
        defaultLocalSocketExceptions = null; 
    } 
  }
  
  static InetSocketAddress getPreBindAddress(InetSocketAddress target) {
    InetSocketAddress result = null;
    if (defaultLocalSocketAddress == null) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Not binding socket to local address before connecting to " + target + " because no default local socket address set.\n");
    } else if (target.isUnresolved()) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Not binding socket to local address " + defaultLocalSocketAddress + " before connecting to " + target + " because target is unresolved.\n");
    } else if (target.getAddress().isLoopbackAddress()) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Not binding socket to local address " + defaultLocalSocketAddress + " before connecting to " + target + " because target is loopback.\n");
    } else if (defaultLocalSocketAddress.getAddress() instanceof Inet4Address && target
      .getAddress() instanceof Inet6Address) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Not binding socket to local address " + defaultLocalSocketAddress + " before connecting to " + target + " because local address is IPv4 and target is IPv6.\n");
    } else if (NetworkDestination.matchList(target.getAddress(), defaultLocalSocketExceptions)) {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Not binding socket to local address " + defaultLocalSocketAddress + " before connecting to " + target + " because target is excluded from pre-binding.\n");
    } else {
      NativeTracer.NETWORK_IO_BASIC_TRACE.tr(() -> "Binding socket to local address " + defaultLocalSocketAddress + " before connecting to " + target + ".\n");
      result = defaultLocalSocketAddress;
    } 
    return result;
  }
  
  private boolean oldImpl = false;
  
  public Socket() {
    setImpl();
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  public Socket(Proxy proxy) {
    if (proxy == null)
      throw new IllegalArgumentException("Invalid Proxy"); 
    Proxy p = (proxy == Proxy.NO_PROXY) ? Proxy.NO_PROXY : ApplicationProxy.create(proxy);
    Proxy.Type type = p.type();
    if (type == Proxy.Type.SOCKS || type == Proxy.Type.HTTP) {
      SecurityManager security = System.getSecurityManager();
      InetSocketAddress epoint = (InetSocketAddress)p.address();
      if (epoint.getAddress() != null)
        checkAddress(epoint.getAddress(), "Socket"); 
      if (security != null) {
        if (epoint.isUnresolved())
          epoint = new InetSocketAddress(epoint.getHostName(), epoint.getPort()); 
        if (epoint.isUnresolved()) {
          security.checkConnect(epoint.getHostName(), epoint.getPort());
        } else {
          security.checkConnect(epoint.getAddress().getHostAddress(), epoint
              .getPort());
        } 
      } 
      this.impl = (type == Proxy.Type.SOCKS) ? new SocksSocketImpl(p) : new HttpConnectSocketImpl(p);
      this.impl.setSocket(this);
    } else if (p == Proxy.NO_PROXY) {
      if (factory == null) {
        this.impl = new PlainSocketImpl(false);
        this.impl.setSocket(this);
      } else {
        setImpl();
      } 
    } else {
      throw new IllegalArgumentException("Invalid Proxy");
    } 
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  protected Socket(SocketImpl impl) throws SocketException {
    this(checkPermission(impl), impl);
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  private Socket(Void ignore, SocketImpl impl) {
    if (impl != null) {
      this.impl = impl;
      checkOldImpl();
      impl.setSocket(this);
    } 
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  private static Void checkPermission(SocketImpl impl) {
    if (impl == null)
      return null; 
    SecurityManager sm = System.getSecurityManager();
    if (sm != null)
      sm.checkPermission(SecurityConstants.SET_SOCKETIMPL_PERMISSION); 
    return null;
  }
  
  public Socket(String host, int port) throws UnknownHostException, IOException {
    this((host != null) ? new InetSocketAddress(host, port) : new InetSocketAddress(
          InetAddress.getByName(null), port), (SocketAddress)null, true);
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  public Socket(InetAddress address, int port) throws IOException {
    this((address != null) ? new InetSocketAddress(address, port) : null, (SocketAddress)null, true);
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  public Socket(String host, int port, InetAddress localAddr, int localPort) throws IOException {
    this((host != null) ? new InetSocketAddress(host, port) : new InetSocketAddress(
          InetAddress.getByName(null), port), new InetSocketAddress(localAddr, localPort), true);
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  public Socket(InetAddress address, int port, InetAddress localAddr, int localPort) throws IOException {
    this((address != null) ? new InetSocketAddress(address, port) : null, new InetSocketAddress(localAddr, localPort), true);
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  @Deprecated
  public Socket(String host, int port, boolean stream) throws IOException {
    this((host != null) ? new InetSocketAddress(host, port) : new InetSocketAddress(
          InetAddress.getByName(null), port), (SocketAddress)null, stream);
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  @Deprecated
  public Socket(InetAddress host, int port, boolean stream) throws IOException {
    this((host != null) ? new InetSocketAddress(host, port) : null, new InetSocketAddress(0), stream);
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  private Socket(SocketAddress address, SocketAddress localAddr, boolean stream) throws IOException {
    setImpl();
    if (address == null)
      throw new NullPointerException(); 
    try {
      createImpl(stream);
      if (localAddr != null)
        bind(localAddr); 
      connect(address);
    } catch (IOException|IllegalArgumentException|SecurityException e) {
      try {
        close();
      } catch (IOException ce) {
        e.addSuppressed(ce);
      } 
      throw e;
    } 
    Object object = null;
    this._m$mObjId = System.identityHashCode(this);
  }
  
  void createImpl(boolean stream) throws SocketException {
    if (this.impl == null)
      setImpl(); 
    try {
      this.impl.create(stream);
      this.created = true;
    } catch (IOException e) {
      throw new SocketException(e.getMessage());
    } 
  }
  
  private void checkOldImpl() {
    if (this.impl == null)
      return; 
    this
      .oldImpl = ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>() {
          public Boolean run() {
            Class<?> clazz = Socket.this.impl.getClass();
            while (true) {
              try {
                clazz.getDeclaredMethod("connect", new Class[] { SocketAddress.class, int.class });
                return Boolean.FALSE;
              } catch (NoSuchMethodException e) {
                clazz = clazz.getSuperclass();
                if (clazz.equals(SocketImpl.class))
                  return Boolean.TRUE; 
              } 
            } 
          }
        })).booleanValue();
  }
  
  void setImpl() {
    if (factory != null) {
      this.impl = factory.createSocketImpl();
      checkOldImpl();
    } else {
      this.impl = new SocksSocketImpl();
    } 
    if (this.impl != null)
      this.impl.setSocket(this); 
  }
  
  SocketImpl getImpl() throws SocketException {
    if (!this.created)
      createImpl(true); 
    return this.impl;
  }
  
  public void connect(SocketAddress endpoint) throws IOException {
    connect(endpoint, 0);
  }
  
  public void connect(SocketAddress endpoint, int timeout) throws IOException {
    _m$mETime = 0L;
    this._m$mFD = getImpl().getFileDescriptor()._m$mGetFd();
    try {
      if (SocketDecoration.action) {
        _m$mETime = System.currentTimeMillis();
        if (ThreadDecoration.action && (Thread.currentThread())._m$mStatus != 16)
          (Thread.currentThread())._m$mStatus = 6; 
      } 
    if (endpoint == null)
      throw new IllegalArgumentException("connect: The address can't be null"); 
    if (timeout < 0)
      throw new IllegalArgumentException("connect: timeout can't be negative"); 
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (!this.oldImpl && isConnected())
      throw new SocketException("already connected"); 
    if (!(endpoint instanceof InetSocketAddress))
      throw new IllegalArgumentException("Unsupported address type"); 
    InetSocketAddress epoint = (InetSocketAddress)endpoint;
    InetAddress addr = epoint.getAddress();
    int port = epoint.getPort();
    checkAddress(addr, "connect");
    SecurityManager security = System.getSecurityManager();
    if (security != null)
      if (epoint.isUnresolved()) {
        security.checkConnect(epoint.getHostName(), port);
      } else {
        security.checkConnect(addr.getHostAddress(), port);
      }  
    if (!this.created)
      createImpl(true); 
    if (!this.bound) {
      InetSocketAddress preBindAddress = getPreBindAddress(epoint);
      if (preBindAddress != null)
        bind(preBindAddress); 
    } 
    try {
      if (!this.oldImpl) {
        this.impl.connect(epoint, timeout);
      } else if (timeout == 0) {
        if (epoint.isUnresolved()) {
          this.impl.connect(addr.getHostName(), port);
        } else {
          this.impl.connect(addr, port);
        } 
      } else {
        throw new UnsupportedOperationException("SocketImpl.connect(addr, timeout)");
      } 
    } catch (IOException e) {
      String host = epoint.getHostOrNull();
      if (host == null) {
        InetAddress inetAddress = epoint.getAddress();
        if (inetAddress != null)
          host = inetAddress.holder().getHostName(); 
      } 
      if (host != null) {
        this.jna.remove(host);
        int idx = host.indexOf('.');
        if (idx > 0)
          this.jna.remove(host.substring(0, idx)); 
      } 
      throw e;
    } 
      this.connected = true;
      this.bound = true;
      Object object1 = null;
      if (SocketDecoration.action)
        SocketDecoration.connected(this, System.currentTimeMillis() - _m$mETime); 
      Object object2 = null;
      if (SocketDecoration.action && ThreadDecoration.action && (Thread.currentThread())._m$mStatus != 16)
        (Thread.currentThread())._m$mStatus = 3; 
      return;
    } catch (Throwable throwable) {
      if (SocketDecoration.action && ThreadDecoration.action && (Thread.currentThread())._m$mStatus != 16)
        (Thread.currentThread())._m$mStatus = 3; 
		
      throw throwable;
	}
  }
  
  public void bind(SocketAddress bindpoint) throws IOException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (!this.oldImpl && isBound())
      throw new SocketException("Already bound"); 
    if (bindpoint != null && !(bindpoint instanceof InetSocketAddress))
      throw new IllegalArgumentException("Unsupported address type"); 
    InetSocketAddress epoint = (InetSocketAddress)bindpoint;
    if (epoint != null && epoint.isUnresolved())
      throw new SocketException("Unresolved address"); 
    if (epoint == null)
      epoint = new InetSocketAddress(0); 
    InetAddress addr = epoint.getAddress();
    int port = epoint.getPort();
    checkAddress(addr, "bind");
    SecurityManager security = System.getSecurityManager();
    if (security != null)
      security.checkListen(port); 
    getImpl().bind(addr, port);
    this.bound = true;
    Object object = null;
    this._m$mFD = getImpl().getFileDescriptor()._m$mGetFd();
  }
  
  private void checkAddress(InetAddress addr, String op) {
    if (addr == null)
      return; 
    if (!(addr instanceof Inet4Address) && !(addr instanceof Inet6Address))
      throw new IllegalArgumentException(op + ": invalid address type"); 
  }
  
  final void postAccept() {
    this.connected = true;
    this.created = true;
    this.bound = true;
    Object object = null;
    this._m$mFD = getImpl().getFileDescriptor()._m$mGetFd();
  }
  
  void setCreated() {
    this.created = true;
  }
  
  void setBound() {
    this.bound = true;
  }
  
  void setConnected() {
    this.connected = true;
  }
  
  public InetAddress getInetAddress() {
    if (!isConnected())
      return null; 
    try {
      return getImpl().getInetAddress();
    } catch (SocketException socketException) {
      return null;
    } 
  }
  
  public InetAddress getLocalAddress() {
    if (!isBound())
      return InetAddress.anyLocalAddress(); 
    InetAddress in = null;
    try {
      in = (InetAddress)getImpl().getOption(15);
      SecurityManager sm = System.getSecurityManager();
      if (sm != null)
        sm.checkConnect(in.getHostAddress(), -1); 
      if (in.isAnyLocalAddress())
        in = InetAddress.anyLocalAddress(); 
    } catch (SecurityException e) {
      in = InetAddress.getLoopbackAddress();
    } catch (Exception e) {
      in = InetAddress.anyLocalAddress();
    } 
    return in;
  }
  
  public int getPort() {
    if (!isConnected())
      return 0; 
    try {
      return getImpl().getPort();
    } catch (SocketException socketException) {
      return -1;
    } 
  }
  
  public int getLocalPort() {
    if (!isBound())
      return -1; 
    try {
      return getImpl().getLocalPort();
    } catch (SocketException socketException) {
      return -1;
    } 
  }
  
  public SocketAddress getRemoteSocketAddress() {
    if (!isConnected())
      return null; 
    return new InetSocketAddress(getInetAddress(), getPort());
  }
  
  public SocketAddress getLocalSocketAddress() {
    if (!isBound())
      return null; 
    return new InetSocketAddress(getLocalAddress(), getLocalPort());
  }
  
  public SocketChannel getChannel() {
    return null;
  }
  
  public InputStream getInputStream() throws IOException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (!isConnected())
      throw new SocketException("Socket is not connected"); 
    if (isInputShutdown())
      throw new SocketException("Socket input is shutdown"); 
    Socket s = this;
    InputStream is = null;
    try {
      is = AccessController.<InputStream>doPrivileged(new PrivilegedExceptionAction<InputStream>() {
            public InputStream run() throws IOException {
              return Socket.this.impl.getInputStream();
            }
          });
    } catch (PrivilegedActionException e) {
      throw (IOException)e.getException();
    } 
    return is;
  }
  
  public OutputStream getOutputStream() throws IOException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (!isConnected())
      throw new SocketException("Socket is not connected"); 
    if (isOutputShutdown())
      throw new SocketException("Socket output is shutdown"); 
    Socket s = this;
    OutputStream os = null;
    try {
      os = AccessController.<OutputStream>doPrivileged(new PrivilegedExceptionAction<OutputStream>() {
            public OutputStream run() throws IOException {
              return Socket.this.impl.getOutputStream();
            }
          });
    } catch (PrivilegedActionException e) {
      throw (IOException)e.getException();
    } 
    return os;
  }
  
  public void setTcpNoDelay(boolean on) throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    getImpl().setOption(1, Boolean.valueOf(on));
  }
  
  public boolean getTcpNoDelay() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    return ((Boolean)getImpl().getOption(1)).booleanValue();
  }
  
  public void setSoLinger(boolean on, int linger) throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (!on) {
      getImpl().setOption(128, new Boolean(on));
    } else {
      if (linger < 0)
        throw new IllegalArgumentException("invalid value for SO_LINGER"); 
      if (linger > 65535)
        linger = 65535; 
      getImpl().setOption(128, new Integer(linger));
    } 
  }
  
  public int getSoLinger() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    Object o = getImpl().getOption(128);
    if (o instanceof Integer)
      return ((Integer)o).intValue(); 
    return -1;
  }
  
  public void sendUrgentData(int data) throws IOException {
    if (!getImpl().supportsUrgentData())
      throw new SocketException("Urgent data not supported"); 
    getImpl().sendUrgentData(data);
  }
  
  public void setOOBInline(boolean on) throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    getImpl().setOption(4099, Boolean.valueOf(on));
  }
  
  public boolean getOOBInline() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    return ((Boolean)getImpl().getOption(4099)).booleanValue();
  }
  
  public synchronized void setSoTimeout(int timeout) throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (timeout < 0)
      throw new IllegalArgumentException("timeout can't be negative"); 
    getImpl().setOption(4102, new Integer(timeout));
  }
  
  public synchronized int getSoTimeout() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    Object o = getImpl().getOption(4102);
    if (o instanceof Integer)
      return ((Integer)o).intValue(); 
    return 0;
  }
  
  public synchronized void setSendBufferSize(int size) throws SocketException {
    if (size <= 0)
      throw new IllegalArgumentException("negative send size"); 
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    getImpl().setOption(4097, new Integer(size));
  }
  
  public synchronized int getSendBufferSize() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    int result = 0;
    Object o = getImpl().getOption(4097);
    if (o instanceof Integer)
      result = ((Integer)o).intValue(); 
    return result;
  }
  
  public synchronized void setReceiveBufferSize(int size) throws SocketException {
    if (size <= 0)
      throw new IllegalArgumentException("invalid receive size"); 
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    getImpl().setOption(4098, new Integer(size));
  }
  
  public synchronized int getReceiveBufferSize() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    int result = 0;
    Object o = getImpl().getOption(4098);
    if (o instanceof Integer)
      result = ((Integer)o).intValue(); 
    return result;
  }
  
  public void setKeepAlive(boolean on) throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    getImpl().setOption(8, Boolean.valueOf(on));
  }
  
  public boolean getKeepAlive() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    return ((Boolean)getImpl().getOption(8)).booleanValue();
  }
  
  public void setTrafficClass(int tc) throws SocketException {
    if (tc < 0 || tc > 255)
      throw new IllegalArgumentException("tc is not in range 0 -- 255"); 
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    try {
      getImpl().setOption(3, Integer.valueOf(tc));
    } catch (SocketException se) {
      if (!isConnected())
        throw se; 
    } 
  }
  
  public int getTrafficClass() throws SocketException {
    return ((Integer)getImpl().getOption(3)).intValue();
  }
  
  public void setReuseAddress(boolean on) throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    getImpl().setOption(4, Boolean.valueOf(on));
  }
  
  public boolean getReuseAddress() throws SocketException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    return ((Boolean)getImpl().getOption(4)).booleanValue();
  }
  
  public synchronized void close() throws IOException {
    if (SocketDecoration.action)
      SocketDecoration.closed(this); 
    synchronized (this.closeLock) {
      if (isClosed())
        return; 
      if (this.created)
        this.impl.close(); 
      this.closed = true;
    } 
  }
  
  public void shutdownInput() throws IOException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (!isConnected())
      throw new SocketException("Socket is not connected"); 
    if (isInputShutdown())
      throw new SocketException("Socket input is already shutdown"); 
    getImpl().shutdownInput();
    this.shutIn = true;
    Object object = null;
    if (SocketDecoration.action)
      SocketDecoration.inputShutdowned(this); 
  }
  
  public void shutdownOutput() throws IOException {
    if (isClosed())
      throw new SocketException("Socket is closed"); 
    if (!isConnected())
      throw new SocketException("Socket is not connected"); 
    if (isOutputShutdown())
      throw new SocketException("Socket output is already shutdown"); 
    getImpl().shutdownOutput();
    this.shutOut = true;
    Object object = null;
    if (SocketDecoration.action)
      SocketDecoration.outputShutdowned(this); 
  }
  
  public String toString() {
    try {
      if (isConnected())
        return "Socket[addr=" + getImpl().getInetAddress() + ",port=" + 
          getImpl().getPort() + ",localport=" + 
          getImpl().getLocalPort() + "]"; 
    } catch (SocketException socketException) {}
    return "Socket[unconnected]";
  }
  
  public boolean isConnected() {
    return (this.connected || this.oldImpl);
  }
  
  public boolean isBound() {
    return (this.bound || this.oldImpl);
  }
  
  public boolean isClosed() {
    synchronized (this.closeLock) {
      return this.closed;
    } 
  }
  
  public boolean isInputShutdown() {
    return this.shutIn;
  }
  
  public boolean isOutputShutdown() {
    return this.shutOut;
  }
  
  private static SocketImplFactory factory = null;
  
  public transient int _m$mId;
  
  public transient int _m$mObjId;
  
  public transient int _m$mFD;
  
  public transient String _m$mLocalAddress;
  
  public transient String _m$mAddress;
  
  public transient boolean _m$mDB;
  
  public transient SocketWeakReference _m$mWeakRef;
  
  public transient boolean _m$mInternalUse;
  
  public transient boolean _m$mUserSession;
  
  public transient CodeData _m$mCode;
  
  public transient boolean _m$mGTUIDKeep;
  
  public static synchronized void setSocketImplFactory(SocketImplFactory fac) throws IOException {
    if (factory != null)
      throw new SocketException("factory already defined"); 
    SecurityManager security = System.getSecurityManager();
    if (security != null)
      security.checkSetFactory(); 
    factory = fac;
  }
  
  public void setPerformancePreferences(int connectionTime, int latency, int bandwidth) {}
  
  public int _m$mGetFd() {
    return getImpl().getFileDescriptor()._m$mGetFd();
  }
  
  static class Socket {}
}
