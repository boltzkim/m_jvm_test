########################################################
# MCM Configuration Env for Application 
########################################################

############
# Config Env
############
export  MCM_HOME=/su3/openmcm
export  MCM_MAT_HOME=$MCM_HOME
export	MCM_CONFIG_FILE=$MCM_HOME/config/mcmconfig_webtob.cfg
export 	MCM_SHLIB=/su3/openmcm/lib/libMcmMSL6swb.so

##########
# Lib Path
##########
#export	LPATH=$LPATH:$MCM_HOME/lib
#export	SHLIB_PATH=$SHLIB_PATH:$MCM_HOME/lib
export	LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$MCM_HOME/lib
#export	LIBPATH=$LIBPATH:$MCM_HOME/lib

##########
# Bin Path
##########
export	PATH=$PATH:$MCM_HOME/bin

###### End of File ####################################
